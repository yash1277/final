package com.ekart.cardinfo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardinfoApplicationTests {

	@Test
	void contextLoads() {
	}

}
