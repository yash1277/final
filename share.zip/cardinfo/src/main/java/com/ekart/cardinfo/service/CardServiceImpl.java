package com.ekart.cardinfo.service;

import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekart.cardinfo.dto.CardDTO;
import com.ekart.cardinfo.entity.Card;
import com.ekart.cardinfo.exception.EKartPaymentException;
import com.ekart.cardinfo.repository.CardRepository;

@Service(value = "cardService")
@Transactional
public class CardServiceImpl implements CardService {

	@Autowired
	private CardRepository cardRepository;

	@Override
	public Integer addCustomerCard(String customerEmailId, CardDTO cardDTO)
			throws EKartPaymentException, NoSuchAlgorithmException {
		Card newCard = new Card();

		/* Verify that card number is unique for a given customer. */
		Optional<Card> cardNumber = cardRepository.findByCardNumber(cardDTO.getCardNumber());
		if (cardNumber.isPresent()) {
			throw new EKartPaymentException("CardService.CARD_ALREADY_PRESENT");
		}
		/* Verify that card number is unique for a given customer. */

		/* Verify that card is not already expired */
		String input = cardDTO.getExpiryMonth() + "/" + cardDTO.getExpiryYear();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/yy");
		simpleDateFormat.setLenient(false);
		try {
			Date expiry = simpleDateFormat.parse(input);
			boolean expired = expiry.before(new Date());
			if (expired == true) {
				throw new EKartPaymentException("CardService.CARD_ALREADY_EXPIRED");
			} else {
				newCard.setExpiryDate(cardDTO.getExpiryMonth() + "/" + cardDTO.getExpiryYear());
			}
		} catch (ParseException e) {
			e.printStackTrace();
		} /* Verify that card is not already expired */
		
		newCard.setNameOnCard(cardDTO.getNameOnCard());
		newCard.setCardNumber(cardDTO.getCardNumber());
		newCard.setCustomerEmailId(customerEmailId);

		cardRepository.save(newCard);
		return newCard.getCardId();
	}// addCustomerCard

	@Override
	public void deleteCard(String customerEmailId, String cardNumber) throws EKartPaymentException {
		List<Card> listOfCustomerCards = cardRepository.findByCustomerEmailId(customerEmailId);
		if (listOfCustomerCards.isEmpty())
			throw new EKartPaymentException("CardService.CUSTOMER_NOT_FOUND");
		Optional<Card> optionalCards = cardRepository.findByCardNumber(cardNumber);
		Card card = optionalCards.orElseThrow(() -> new EKartPaymentException("CardService.CARD_NOT_FOUND"));
		cardRepository.delete(card);
	}

	@Override
	public List<CardDTO> getCardsOfCustomer(String customerEmailId) throws EKartPaymentException {
		List<Card> listOfCustomerCards = cardRepository.findByCustomerEmailId(customerEmailId);
		if (listOfCustomerCards.isEmpty())
			throw new EKartPaymentException("CardService.CUSTOMER_NOT_FOUND");
		List<CardDTO> cardDTOs = new ArrayList<CardDTO>();
		for (Card card : listOfCustomerCards) {
			CardDTO cardDTO = new CardDTO();
			cardDTO.setNameOnCard(card.getNameOnCard());
			cardDTO.setCardNumber(card.getCardNumber());
			String[] expiryDate = card.getExpiryDate().split("/");
			cardDTO.setExpiryMonth(expiryDate[0]);
			cardDTO.setExpiryYear(expiryDate[1]);

			cardDTOs.add(cardDTO);
		}
		return cardDTOs;
	}// getCardsOfCustomer

	@Override
	public CardDTO getCard(String cardNumber) throws EKartPaymentException {
		Optional<Card> optionalCards = cardRepository.findByCardNumber(cardNumber);
		Card card = optionalCards.orElseThrow(() -> new EKartPaymentException("CardService.CARD_NOT_FOUND"));
		CardDTO cardDTO = new CardDTO();
		cardDTO.setNameOnCard(card.getNameOnCard());
		cardDTO.setCardNumber(card.getCardNumber());
		String[] expiryDate = card.getExpiryDate().split("/");
		cardDTO.setExpiryMonth(expiryDate[0]);
		cardDTO.setExpiryYear(expiryDate[1]);
		return cardDTO;
	}// getCard

}
