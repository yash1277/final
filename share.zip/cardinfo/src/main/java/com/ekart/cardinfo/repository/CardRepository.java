package com.ekart.cardinfo.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ekart.cardinfo.entity.Card;

@Repository
public interface CardRepository extends JpaRepository<Card, Integer>{
	List<Card> findByCustomerEmailId(String customerEmailId);
	Optional<Card> findByCardNumber(String cardNumber);
}
