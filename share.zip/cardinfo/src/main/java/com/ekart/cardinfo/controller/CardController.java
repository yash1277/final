package com.ekart.cardinfo.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.cardinfo.dto.CardDTO;
import com.ekart.cardinfo.exception.EKartPaymentException;
import com.ekart.cardinfo.service.CardService;

@CrossOrigin
@RestController
@Validated
@RequestMapping(value = "/")
public class CardController {

	@Autowired
	private CardService cardService;
	@Autowired
	private Environment environment;

	private static final Log LOGGER = LogFactory.getLog(CardController.class);

	@PostMapping(value = "{customerEmailId:.+}/card/add")
	public ResponseEntity<String> addNewCard(@RequestBody CardDTO cardDTO,
			@PathVariable("customerEmailId") String customerEmailId)
			throws EKartPaymentException, NoSuchAlgorithmException {
		LOGGER.info("Recieved request to add new  card for customer : " + customerEmailId);

		int cardId = cardService.addCustomerCard(customerEmailId, cardDTO);
		String message = environment.getProperty("CardController.NEW_CARD_ADDED_SUCCESS");
		String toReturn = message + cardId;
		toReturn = toReturn.trim();
		return new ResponseEntity<>(toReturn, HttpStatus.OK);
	}// addNewCard

	@DeleteMapping(value = "{customerEmailId:.+}/card/{cardNumber}/delete")
	public ResponseEntity<String> deleteCard(@PathVariable("cardNumber") String cardnumber,
			@PathVariable("customerEmailId") String customerEmailId) throws EKartPaymentException {
		LOGGER.info("Recieved request to delete  card :" + cardnumber + " of customer : " + customerEmailId);
		cardService.deleteCard(customerEmailId, cardnumber);
		String modificationSuccessMsg = environment.getProperty("CardController.CUSTOMER_CARD_DELETED_SUCCESS");
		return new ResponseEntity<>(modificationSuccessMsg, HttpStatus.OK);
	}//deleteCard

	@GetMapping(value = "{customerEmailId}/cards")
	public ResponseEntity<List<CardDTO>> getCardsOfCustomer(@PathVariable("customerEmailId") String customerEmailId)
			throws EKartPaymentException {
		LOGGER.info("Recieved request to get List of cards :" + customerEmailId);
		List<CardDTO> cardDTOs = cardService.getCardsOfCustomer(customerEmailId);
		return new ResponseEntity<>(cardDTOs, HttpStatus.OK);
	}//getCardsOfCustomer
	
	@GetMapping(value = "card/{cardNumber}")
	public ResponseEntity<CardDTO> getCard(@PathVariable("cardNumber") String cardNumber) throws EKartPaymentException {
		LOGGER.info("Recieved request to get  card :" + cardNumber);
		CardDTO cardDTO = cardService.getCard(cardNumber);
		return new ResponseEntity<>(cardDTO, HttpStatus.OK);
	}//getCard
}
