package com.ekart.cardinfo.service;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.ekart.cardinfo.dto.CardDTO;
import com.ekart.cardinfo.exception.EKartPaymentException;

public interface CardService {

	Integer addCustomerCard(String customerEmailId, CardDTO cardDTO) throws EKartPaymentException, NoSuchAlgorithmException;
	CardDTO getCard(String cardNumber) throws EKartPaymentException;
	void deleteCard(String customerEmailId, String cardNumber) throws EKartPaymentException;
	List<CardDTO> getCardsOfCustomer(String customerEmailId) throws EKartPaymentException;
}
