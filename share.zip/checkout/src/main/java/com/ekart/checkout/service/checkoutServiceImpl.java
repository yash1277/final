package com.ekart.checkout.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ekart.checkout.Repo.checkoutRepository;
import com.ekart.checkout.dto.checkoutDto;
import com.ekart.checkout.entity.checkoutEntity;
import com.ekart.checkout.exception.PaymentException;


@Service
public class checkoutServiceImpl implements checkoutService {
	
	@Autowired
	checkoutRepository checkoutrepo;
	
	@Override
	public String addcheckoutdetails(checkoutDto cdto , int userid) {
		checkoutEntity a=new checkoutEntity();
		a.setPaymentMethod(cdto.getPaymentMethod());
		a.setPname(cdto.getPname());
		a.setShippingAddress(cdto.getShippingAddress());
		a.setUserId(userid);
		a.setStatus("payment pending");
		checkoutrepo.save(a);
		return userid+"product checked-out sucessfullly"; 
	}
	
	@Override
	public Integer GetOrderID(int userid,String pname) throws PaymentException {
			checkoutEntity temp = checkoutrepo.findByUserId(userid,pname);
			if (temp.equals(null)) {
				throw new PaymentException("user id is not found!!!");
			}
			temp.setStatus("payment sucessfull");
			checkoutrepo.save(temp);
			return temp.getOrderId();
			 
	}

}
