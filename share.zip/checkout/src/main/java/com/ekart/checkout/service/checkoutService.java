package com.ekart.checkout.service;

import org.springframework.stereotype.Service;

import com.ekart.checkout.dto.checkoutDto;
import com.ekart.checkout.exception.PaymentException;


@Service
public interface checkoutService {

	String addcheckoutdetails(checkoutDto cdto, int userid);
	Integer GetOrderID(int userid,String pname) throws PaymentException;
	
}
