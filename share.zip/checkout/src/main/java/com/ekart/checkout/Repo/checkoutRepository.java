package com.ekart.checkout.Repo;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ekart.checkout.entity.checkoutEntity;


@Repository
public interface checkoutRepository extends JpaRepository<checkoutEntity,Integer>{
	
	@Query(value="SELECT *FROM checkout_table WHERE user_id=:userid and  pname=:pname " ,nativeQuery=true)
	checkoutEntity findByUserId(@Param("userid")int userid,@Param("pname")String pname);

}
