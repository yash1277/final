package com.ekart.checkout.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ekart.checkout.dto.checkoutDto;
import com.ekart.checkout.exception.PaymentException;
import com.ekart.checkout.service.checkoutService;


@RestController
public class checkoutController {
	
	@Autowired
	checkoutService checkserv;
	
	@PostMapping("{userid}/checkout")
	public String toUpdateCheckout(@RequestBody checkoutDto cdto,@PathVariable("userid") Integer userid){
		return checkserv.addcheckoutdetails(cdto,userid);
		
	}
	
	@GetMapping("{userid}/{pname}/paymentsucessfull")
	public Integer togetOrderId(@PathVariable("userid") int userid,@PathVariable("pname") String pname) throws PaymentException{
		return checkserv.GetOrderID(userid,pname);
		
	}
}
