package com.ekart.checkout.entity;


	import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
	import javax.persistence.Table;
	
	
	
	@Entity
	@Table(name="checkoutTable")
	public class checkoutEntity {
	
	private	Integer userId;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private	int orderId;
	
	private String shippingAddress;
	private String paymentMethod;
	private String pname;
	private String status;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public checkoutEntity() {
		
	}

	public checkoutEntity(Integer userId, Integer orderId, String shippingAddress, String paymentMethod, String pname,
			String status) {
		super();
		this.userId = userId;
		this.orderId = orderId;
		this.shippingAddress = shippingAddress;
		this.paymentMethod = paymentMethod;
		this.pname = pname;
		this.status = status;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public String getShippingAddress() {
		return shippingAddress;
	}
	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	
}
